import Layout from "@/components/Layout";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function About() {
  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            {/* Hero Section */}
            <div className="bg-gradient-to-r from-primary to-primary-dark text-white py-12 px-4">
              <div className="text-center">
                <h1 className="text-4xl font-bold mb-4">About ElectroMart</h1>
                <p className="text-lg text-blue-100 max-w-2xl mx-auto">
                  Learn about our mission to provide quality electronics components for makers and engineers worldwide.
                </p>
              </div>
            </div>

            {/* Content */}
            <div className="p-8 md:p-12">
              <div className="max-w-3xl mx-auto space-y-8">
                <div>
                  <h2 className="text-2xl font-bold text-charcoal mb-4">
                    Our Story
                  </h2>
                  <p className="text-gray-600">
                    This is where the story of ElectroMart will be told. Share information about how the company was founded, its mission, and vision.
                  </p>
                </div>

                <div className="bg-blue-50 border-l-4 border-primary p-6 rounded">
                  <p className="text-gray-700 font-medium mb-2">Page sections to implement:</p>
                  <ul className="text-gray-600 space-y-2 list-disc list-inside">
                    <li>Company story and history</li>
                    <li>Mission and vision statement</li>
                    <li>Team members with photos and bios</li>
                    <li>Company values and achievements</li>
                    <li>Why choose us section</li>
                    <li>Contact call-to-action</li>
                  </ul>
                </div>

                <div className="flex gap-4 pt-4">
                  <Link
                    to="/"
                    className="inline-flex items-center gap-2 bg-primary text-white font-bold py-3 px-8 rounded-lg hover:bg-primary-dark transition-all duration-300 hover:shadow-lg active:scale-95"
                  >
                    Back to Home
                    <ArrowRight className="w-5 h-5" />
                  </Link>
                  <Link
                    to="/contact"
                    className="inline-flex items-center gap-2 border-2 border-primary text-primary font-bold py-3 px-8 rounded-lg hover:bg-primary hover:text-white transition-all duration-300"
                  >
                    Contact Us
                    <ArrowRight className="w-5 h-5" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

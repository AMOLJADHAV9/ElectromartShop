import { ArrowRight, Zap, Radio, Cpu, Rocket } from "lucide-react";
import { Link } from "react-router-dom";
import Layout from "@/components/Layout";
import ProductCard from "@/components/ProductCard";
import CategoryCard from "@/components/CategoryCard";
import { useState } from "react";

// Sample product data
const featuredProducts = [
  {
    id: "1",
    name: "Arduino Uno R3",
    price: 599,
    originalPrice: 899,
    image: "https://images.pexels.com/photos/343457/pexels-photo-343457.jpeg",
    category: "Arduino",
    rating: 4.8,
    reviews: 145,
    description: "The classic Arduino board for all beginners.",
    inStock: true,
  },
  {
    id: "2",
    name: "Ultrasonic Sensor HC-SR04",
    price: 120,
    image: "https://images.pexels.com/photos/14887613/pexels-photo-14887613.jpeg",
    category: "Sensors",
    rating: 4.6,
    reviews: 89,
    description: "Distance measurement sensor module.",
    inStock: true,
  },
  {
    id: "3",
    name: "ESP32 WiFi + Bluetooth Module",
    price: 290,
    originalPrice: 450,
    image: "https://images.pexels.com/photos/3568521/pexels-photo-3568521.jpeg",
    category: "Modules",
    rating: 4.9,
    reviews: 234,
    description: "Powerful microcontroller for IoT projects.",
    inStock: true,
  },
  {
    id: "4",
    name: "5V Relay Module",
    price: 99,
    image: "https://images.pexels.com/photos/7254460/pexels-photo-7254460.jpeg",
    category: "Modules",
    rating: 4.5,
    reviews: 56,
    description: "Single-channel relay for switching control circuits.",
    inStock: true,
  },
  {
    id: "5",
    name: "DHT11 Temperature & Humidity Sensor",
    price: 149,
    originalPrice: 199,
    image: "https://images.pexels.com/photos/343457/pexels-photo-343457.jpeg",
    category: "Sensors",
    rating: 4.4,
    reviews: 102,
    description: "Accurate temperature and humidity measurement.",
    inStock: true,
  },
  {
    id: "6",
    name: "Arduino Nano",
    price: 349,
    image: "https://images.pexels.com/photos/14887613/pexels-photo-14887613.jpeg",
    category: "Arduino",
    rating: 4.7,
    reviews: 178,
    description: "Compact Arduino board for space-constrained projects.",
    inStock: true,
  },
  {
    id: "7",
    name: "Bluetooth HC-05 Module",
    price: 499,
    originalPrice: 699,
    image: "https://images.pexels.com/photos/3568521/pexels-photo-3568521.jpeg",
    category: "Modules",
    rating: 4.6,
    reviews: 127,
    description: "Wireless serial communication module.",
    inStock: true,
  },
  {
    id: "8",
    name: "4-Channel Relay Module",
    price: 299,
    image: "https://images.pexels.com/photos/7254460/pexels-photo-7254460.jpeg",
    category: "Modules",
    rating: 4.5,
    reviews: 73,
    description: "Multi-channel relay for complex switching.",
    inStock: true,
  },
];

const categories = [
  {
    name: "Arduino Boards",
    icon: "🎛️",
    description: "Uno, Nano, Mega, and more",
    productCount: 24,
    color: "blue" as const,
  },
  {
    name: "Sensors",
    icon: "📡",
    description: "Ultrasonic, IR, DHT11, and more",
    productCount: 45,
    color: "orange" as const,
  },
  {
    name: "Modules",
    icon: "🔌",
    description: "Bluetooth, WiFi, Relay, Motor",
    productCount: 38,
    color: "green" as const,
  },
  {
    name: "Robotics",
    icon: "🤖",
    description: "Kits, Motors, and Wheels",
    productCount: 18,
    color: "purple" as const,
  },
];

const limitedOffers = [
  {
    title: "Flash Sale - 50% Off",
    description: "Selected Arduino Boards",
    discount: "50%",
    image:
      "https://images.pexels.com/photos/343457/pexels-photo-343457.jpeg",
  },
  {
    title: "Bundle Deal - Save Big",
    description: "Sensor Starter Kit",
    discount: "40%",
    image: "https://images.pexels.com/photos/14887613/pexels-photo-14887613.jpeg",
  },
];

export default function Home() {
  const [currentOfferIndex, setCurrentOfferIndex] = useState(0);

  const nextOffer = () => {
    setCurrentOfferIndex((prev) => (prev + 1) % limitedOffers.length);
  };

  const prevOffer = () => {
    setCurrentOfferIndex(
      (prev) => (prev - 1 + limitedOffers.length) % limitedOffers.length
    );
  };

  return (
    <Layout>
      {/* Hero Banner */}
      <section className="bg-gradient-to-r from-primary to-primary-dark text-white py-12 sm:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            {/* Left Side - Text */}
            <div className="space-y-6">
              <h1 className="text-4xl sm:text-5xl font-bold leading-tight">
                Your One-Stop Electronics Store
              </h1>
              <p className="text-lg text-blue-100">
                Explore Arduino, Sensors, Modules & More! Everything you need for your electronics projects.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/products"
                  className="bg-neon-orange hover:bg-orange-600 text-white font-bold py-3 px-8 rounded-lg inline-flex items-center gap-2 transition-all duration-300 hover:shadow-lg active:scale-95"
                >
                  Shop Now
                  <ArrowRight className="w-5 h-5" />
                </Link>
                <button className="border-2 border-white text-white hover:bg-white hover:text-primary font-bold py-3 px-8 rounded-lg transition-all duration-300">
                  Learn More
                </button>
              </div>
            </div>

            {/* Right Side - Hero Image */}
            <div className="hidden md:block">
              <img
                src="https://images.pexels.com/photos/3568521/pexels-photo-3568521.jpeg"
                alt="Electronics Store"
                className="w-full rounded-lg shadow-2xl object-cover h-96"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-16 sm:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-charcoal mb-3">
              Shop by Category
            </h2>
            <p className="text-gray-600 text-lg">
              Explore our wide range of electronic components
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category) => (
              <CategoryCard key={category.name} {...category} />
            ))}
          </div>
        </div>
      </section>

      {/* Limited Time Offers */}
      <section className="py-16 sm:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl sm:text-4xl font-bold text-charcoal mb-8 text-center">
            Limited Time Offers
          </h2>

          <div className="relative">
            {/* Carousel */}
            <div className="relative overflow-hidden rounded-xl">
              <img
                src={limitedOffers[currentOfferIndex].image}
                alt={limitedOffers[currentOfferIndex].title}
                className="w-full h-64 sm:h-96 object-cover"
              />

              {/* Overlay Content */}
              <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-white text-center">
                <h3 className="text-2xl sm:text-4xl font-bold mb-2">
                  {limitedOffers[currentOfferIndex].title}
                </h3>
                <p className="text-lg sm:text-xl mb-4">
                  {limitedOffers[currentOfferIndex].description}
                </p>
                <div className="text-5xl sm:text-6xl font-bold text-neon-orange">
                  {limitedOffers[currentOfferIndex].discount}
                </div>
              </div>
            </div>

            {/* Navigation Buttons */}
            <button
              onClick={prevOffer}
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-charcoal p-3 rounded-full transition-all duration-300 z-10"
              aria-label="Previous offer"
            >
              <ArrowRight className="w-5 h-5 rotate-180" />
            </button>
            <button
              onClick={nextOffer}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-charcoal p-3 rounded-full transition-all duration-300 z-10"
              aria-label="Next offer"
            >
              <ArrowRight className="w-5 h-5" />
            </button>

            {/* Indicators */}
            <div className="flex justify-center gap-2 mt-4">
              {limitedOffers.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentOfferIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentOfferIndex ? "bg-primary w-8" : "bg-gray-300"
                  }`}
                  aria-label={`Go to offer ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Trending Products */}
      <section className="py-16 sm:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold text-charcoal mb-2">
                Trending Products
              </h2>
              <p className="text-gray-600">
                Most popular items this week
              </p>
            </div>
            <Link
              to="/products"
              className="text-primary font-semibold hover:text-primary-dark flex items-center gap-2 transition-colors"
            >
              View All
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.slice(0, 8).map((product) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 sm:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl sm:text-4xl font-bold text-charcoal text-center mb-12">
            Why Choose ElectroMart?
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Feature 1 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-charcoal mb-2">
                Fast Shipping
              </h3>
              <p className="text-gray-600">
                Get your orders delivered within 2-3 business days
              </p>
            </div>

            {/* Feature 2 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Radio className="w-8 h-8 text-neon-orange" />
              </div>
              <h3 className="text-xl font-bold text-charcoal mb-2">
                Authentic Products
              </h3>
              <p className="text-gray-600">
                100% genuine electronics from trusted brands
              </p>
            </div>

            {/* Feature 3 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Cpu className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-charcoal mb-2">
                Expert Support
              </h3>
              <p className="text-gray-600">
                Get technical guidance from our experienced team
              </p>
            </div>

            {/* Feature 4 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Rocket className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold text-charcoal mb-2">
                Best Prices
              </h3>
              <p className="text-gray-600">
                Competitive prices with exclusive discounts
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="bg-gradient-to-r from-primary to-primary-dark text-white py-16 sm:py-20">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Subscribe to Our Newsletter
          </h2>
          <p className="text-lg text-blue-100 mb-8">
            Get exclusive deals, product launches, and tech tips delivered to your inbox
          </p>

          <form className="flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 rounded-lg text-charcoal font-medium outline-none focus:ring-2 focus:ring-neon-orange"
            />
            <button
              type="submit"
              className="bg-neon-orange hover:bg-orange-600 text-white font-bold py-3 px-8 rounded-lg transition-all duration-300 hover:shadow-lg active:scale-95 whitespace-nowrap"
            >
              Subscribe
            </button>
          </form>

          <p className="text-blue-100 text-sm mt-4">
            We respect your privacy. Unsubscribe at any time.
          </p>
        </div>
      </section>
    </Layout>
  );
}

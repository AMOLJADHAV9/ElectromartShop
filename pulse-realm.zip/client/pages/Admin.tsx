import Layout from "@/components/Layout";
import {
  BarChart3,
  Package,
  Users,
  ShoppingBag,
  Plus,
  Edit2,
  Trash2,
  Eye,
  TrendingUp,
  DollarSign,
  Grid,
} from "lucide-react";
import { useState } from "react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  rating: number;
  sales: number;
}

interface User {
  id: string;
  name: string;
  email: string;
  joinDate: string;
  totalOrders: number;
  totalSpent: number;
}

interface Order {
  id: string;
  customer: string;
  date: string;
  amount: number;
  status: "pending" | "processing" | "shipped" | "delivered";
  items: number;
}

const mockProducts: Product[] = [
  {
    id: "1",
    name: "Arduino Uno R3",
    category: "Arduino",
    price: 599,
    stock: 45,
    rating: 4.8,
    sales: 234,
  },
  {
    id: "2",
    name: "Ultrasonic Sensor HC-SR04",
    category: "Sensors",
    price: 120,
    stock: 156,
    rating: 4.6,
    sales: 456,
  },
  {
    id: "3",
    name: "ESP32 WiFi Module",
    category: "Modules",
    price: 290,
    stock: 78,
    rating: 4.9,
    sales: 389,
  },
  {
    id: "4",
    name: "5V Relay Module",
    category: "Modules",
    price: 99,
    stock: 234,
    rating: 4.5,
    sales: 567,
  },
];

const mockUsers: User[] = [
  {
    id: "u1",
    name: "Rajesh Kumar",
    email: "rajesh@example.com",
    joinDate: "2024-01-15",
    totalOrders: 12,
    totalSpent: 5400,
  },
  {
    id: "u2",
    name: "Priya Sharma",
    email: "priya@example.com",
    joinDate: "2024-02-20",
    totalOrders: 8,
    totalSpent: 3200,
  },
  {
    id: "u3",
    name: "Amit Patel",
    email: "amit@example.com",
    joinDate: "2024-03-10",
    totalOrders: 15,
    totalSpent: 7800,
  },
  {
    id: "u4",
    name: "Neha Singh",
    email: "neha@example.com",
    joinDate: "2024-01-25",
    totalOrders: 6,
    totalSpent: 2100,
  },
];

const mockOrders: Order[] = [
  {
    id: "ORD001",
    customer: "Rajesh Kumar",
    date: "2024-11-20",
    amount: 1299,
    status: "delivered",
    items: 3,
  },
  {
    id: "ORD002",
    customer: "Priya Sharma",
    date: "2024-11-19",
    amount: 599,
    status: "shipped",
    items: 1,
  },
  {
    id: "ORD003",
    customer: "Amit Patel",
    date: "2024-11-19",
    amount: 2099,
    status: "processing",
    items: 4,
  },
  {
    id: "ORD004",
    customer: "Neha Singh",
    date: "2024-11-18",
    amount: 890,
    status: "pending",
    items: 2,
  },
];

const salesData = [
  { month: "Jan", sales: 4000, revenue: 24000 },
  { month: "Feb", sales: 3000, revenue: 18000 },
  { month: "Mar", sales: 5000, revenue: 32000 },
  { month: "Apr", sales: 4500, revenue: 27000 },
  { month: "May", sales: 6000, revenue: 38000 },
  { month: "Jun", sales: 5500, revenue: 35000 },
];

const categoryData = [
  { name: "Arduino", value: 45, color: "#007BFF" },
  { name: "Sensors", value: 30, color: "#FF9900" },
  { name: "Modules", value: 20, color: "#00FF7F" },
  { name: "Robotics", value: 5, color: "#9D4EDD" },
];

export default function Admin() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [products, setProducts] = useState(mockProducts);
  const [users] = useState(mockUsers);
  const [orders] = useState(mockOrders);
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const [formData, setFormData] = useState({
    name: "",
    category: "",
    price: "",
    stock: "",
  });

  const totalRevenue = products.reduce((acc, p) => acc + p.price * p.sales, 0);
  const totalOrders = products.reduce((acc, p) => acc + p.sales, 0);
  const totalProducts = products.length;
  const totalUsers = users.length;

  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: BarChart3 },
    { id: "products", label: "Products", icon: Package },
    { id: "users", label: "Users", icon: Users },
    { id: "orders", label: "Orders", icon: ShoppingBag },
  ];

  const handleAddProduct = () => {
    if (formData.name && formData.category && formData.price && formData.stock) {
      const newProduct: Product = {
        id: Math.random().toString(),
        name: formData.name,
        category: formData.category,
        price: parseInt(formData.price),
        stock: parseInt(formData.stock),
        rating: 4.5,
        sales: 0,
      };

      if (editingProduct) {
        setProducts(
          products.map((p) => (p.id === editingProduct.id ? newProduct : p))
        );
        setEditingProduct(null);
      } else {
        setProducts([...products, newProduct]);
      }

      setFormData({ name: "", category: "", price: "", stock: "" });
      setShowProductForm(false);
    }
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      category: product.category,
      price: product.price.toString(),
      stock: product.stock.toString(),
    });
    setShowProductForm(true);
  };

  const handleDeleteProduct = (id: string) => {
    setProducts(products.filter((p) => p.id !== id));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered":
        return "bg-green-100 text-green-800";
      case "shipped":
        return "bg-blue-100 text-blue-800";
      case "processing":
        return "bg-yellow-100 text-yellow-800";
      case "pending":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gray-900">
        <div className="max-w-7xl mx-auto flex gap-6 p-4 sm:p-8">
          {/* Sidebar */}
          <div className="w-64 bg-gray-800 rounded-lg shadow-xl p-6 h-fit sticky top-20">
            <h3 className="text-xl font-bold text-white mb-6">Admin Panel</h3>

            <nav className="space-y-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setShowProductForm(false);
                      setEditingProduct(null);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-all ${
                      activeTab === item.id
                        ? "bg-primary text-white shadow-lg"
                        : "text-gray-300 hover:bg-gray-700"
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Dashboard Tab */}
            {activeTab === "dashboard" && (
              <div className="space-y-6">
                <div>
                  <h1 className="text-4xl font-bold text-white mb-2">
                    Dashboard
                  </h1>
                  <p className="text-gray-400">
                    Welcome to ElectroMart Admin Dashboard
                  </p>
                </div>

                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="bg-gradient-to-br from-primary to-primary-dark rounded-lg shadow-lg p-6 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-primary-foreground/80 text-sm mb-1">
                          Total Revenue
                        </p>
                        <p className="text-3xl font-bold">
                          ₹{(totalRevenue / 100000).toFixed(2)}L
                        </p>
                      </div>
                      <DollarSign className="w-12 h-12 opacity-30" />
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-neon-orange to-orange-600 rounded-lg shadow-lg p-6 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white/80 text-sm mb-1">
                          Total Orders
                        </p>
                        <p className="text-3xl font-bold">{totalOrders}</p>
                      </div>
                      <ShoppingBag className="w-12 h-12 opacity-30" />
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-green-500 to-green-700 rounded-lg shadow-lg p-6 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white/80 text-sm mb-1">
                          Total Products
                        </p>
                        <p className="text-3xl font-bold">{totalProducts}</p>
                      </div>
                      <Grid className="w-12 h-12 opacity-30" />
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-purple-500 to-purple-700 rounded-lg shadow-lg p-6 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white/80 text-sm mb-1">
                          Total Users
                        </p>
                        <p className="text-3xl font-bold">{totalUsers}</p>
                      </div>
                      <Users className="w-12 h-12 opacity-30" />
                    </div>
                  </div>
                </div>

                {/* Charts */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Sales Chart */}
                  <div className="bg-gray-800 rounded-lg shadow-lg p-6">
                    <h2 className="text-xl font-bold text-white mb-4">
                      Monthly Sales & Revenue
                    </h2>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={salesData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                        <XAxis stroke="#999" />
                        <YAxis stroke="#999" />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#333",
                            border: "1px solid #555",
                            borderRadius: "8px",
                          }}
                        />
                        <Legend />
                        <Bar
                          dataKey="sales"
                          fill="#007BFF"
                          name="Orders"
                          radius={[8, 8, 0, 0]}
                        />
                        <Bar
                          dataKey="revenue"
                          fill="#FF9900"
                          name="Revenue"
                          radius={[8, 8, 0, 0]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Category Distribution */}
                  <div className="bg-gray-800 rounded-lg shadow-lg p-6">
                    <h2 className="text-xl font-bold text-white mb-4">
                      Product Category Distribution
                    </h2>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={categoryData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, value }) => `${name} ${value}%`}
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {categoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Revenue Trend */}
                <div className="bg-gray-800 rounded-lg shadow-lg p-6">
                  <h2 className="text-xl font-bold text-white mb-4">
                    Revenue Trend
                  </h2>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                      <XAxis stroke="#999" />
                      <YAxis stroke="#999" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#333",
                          border: "1px solid #555",
                          borderRadius: "8px",
                        }}
                      />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="revenue"
                        stroke="#FF9900"
                        strokeWidth={3}
                        dot={{ fill: "#FF9900", r: 5 }}
                        activeDot={{ r: 7 }}
                        name="Revenue (₹)"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {/* Products Tab */}
            {activeTab === "products" && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h1 className="text-3xl font-bold text-white">
                    Products Management
                  </h1>
                  <button
                    onClick={() => {
                      setShowProductForm(!showProductForm);
                      setEditingProduct(null);
                      setFormData({
                        name: "",
                        category: "",
                        price: "",
                        stock: "",
                      });
                    }}
                    className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded-lg flex items-center gap-2 transition-all"
                  >
                    <Plus className="w-5 h-5" />
                    Add Product
                  </button>
                </div>

                {/* Product Form */}
                {showProductForm && (
                  <div className="bg-gray-800 rounded-lg shadow-lg p-6">
                    <h3 className="text-xl font-bold text-white mb-4">
                      {editingProduct ? "Edit Product" : "Add New Product"}
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-gray-300 font-semibold mb-2">
                          Product Name
                        </label>
                        <input
                          type="text"
                          value={formData.name}
                          onChange={(e) =>
                            setFormData({ ...formData, name: e.target.value })
                          }
                          placeholder="Enter product name"
                          className="w-full px-4 py-2 bg-gray-700 text-white rounded-lg outline-none focus:ring-2 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="block text-gray-300 font-semibold mb-2">
                          Category
                        </label>
                        <select
                          value={formData.category}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              category: e.target.value,
                            })
                          }
                          className="w-full px-4 py-2 bg-gray-700 text-white rounded-lg outline-none focus:ring-2 focus:ring-primary"
                        >
                          <option value="">Select Category</option>
                          <option value="Arduino">Arduino</option>
                          <option value="Sensors">Sensors</option>
                          <option value="Modules">Modules</option>
                          <option value="Robotics">Robotics</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-gray-300 font-semibold mb-2">
                          Price (₹)
                        </label>
                        <input
                          type="number"
                          value={formData.price}
                          onChange={(e) =>
                            setFormData({ ...formData, price: e.target.value })
                          }
                          placeholder="Enter price"
                          className="w-full px-4 py-2 bg-gray-700 text-white rounded-lg outline-none focus:ring-2 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="block text-gray-300 font-semibold mb-2">
                          Stock
                        </label>
                        <input
                          type="number"
                          value={formData.stock}
                          onChange={(e) =>
                            setFormData({ ...formData, stock: e.target.value })
                          }
                          placeholder="Enter stock quantity"
                          className="w-full px-4 py-2 bg-gray-700 text-white rounded-lg outline-none focus:ring-2 focus:ring-primary"
                        />
                      </div>
                    </div>
                    <div className="flex gap-3 mt-4">
                      <button
                        onClick={handleAddProduct}
                        className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-6 rounded-lg transition-all"
                      >
                        {editingProduct ? "Update Product" : "Add Product"}
                      </button>
                      <button
                        onClick={() => {
                          setShowProductForm(false);
                          setEditingProduct(null);
                          setFormData({
                            name: "",
                            category: "",
                            price: "",
                            stock: "",
                          });
                        }}
                        className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-6 rounded-lg transition-all"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}

                {/* Products Table */}
                <div className="bg-gray-800 rounded-lg shadow-lg overflow-x-auto">
                  <table className="w-full text-left text-gray-300">
                    <thead className="bg-gray-700 text-white">
                      <tr>
                        <th className="px-6 py-4 font-bold">Name</th>
                        <th className="px-6 py-4 font-bold">Category</th>
                        <th className="px-6 py-4 font-bold">Price</th>
                        <th className="px-6 py-4 font-bold">Stock</th>
                        <th className="px-6 py-4 font-bold">Rating</th>
                        <th className="px-6 py-4 font-bold">Sales</th>
                        <th className="px-6 py-4 font-bold">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {products.map((product) => (
                        <tr
                          key={product.id}
                          className="border-t border-gray-700 hover:bg-gray-700 transition-colors"
                        >
                          <td className="px-6 py-4">{product.name}</td>
                          <td className="px-6 py-4">
                            <span className="bg-primary/20 text-primary px-3 py-1 rounded-full text-sm">
                              {product.category}
                            </span>
                          </td>
                          <td className="px-6 py-4 font-semibold">
                            ₹{product.price}
                          </td>
                          <td className="px-6 py-4">
                            <span
                              className={`px-3 py-1 rounded-full text-sm font-semibold ${
                                product.stock > 100
                                  ? "bg-green-500/20 text-green-300"
                                  : product.stock > 0
                                    ? "bg-yellow-500/20 text-yellow-300"
                                    : "bg-red-500/20 text-red-300"
                              }`}
                            >
                              {product.stock}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="flex items-center gap-1">
                              ⭐ {product.rating}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="flex items-center gap-1">
                              <TrendingUp className="w-4 h-4 text-neon-orange" />
                              {product.sales}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleEditProduct(product)}
                                className="bg-blue-500 hover:bg-blue-600 p-2 rounded-lg transition-colors"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteProduct(product.id)}
                                className="bg-red-500 hover:bg-red-600 p-2 rounded-lg transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Users Tab */}
            {activeTab === "users" && (
              <div className="space-y-6">
                <h1 className="text-3xl font-bold text-white">
                  Users Management
                </h1>

                <div className="bg-gray-800 rounded-lg shadow-lg overflow-x-auto">
                  <table className="w-full text-left text-gray-300">
                    <thead className="bg-gray-700 text-white">
                      <tr>
                        <th className="px-6 py-4 font-bold">Name</th>
                        <th className="px-6 py-4 font-bold">Email</th>
                        <th className="px-6 py-4 font-bold">Join Date</th>
                        <th className="px-6 py-4 font-bold">Orders</th>
                        <th className="px-6 py-4 font-bold">Total Spent</th>
                        <th className="px-6 py-4 font-bold">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((user) => (
                        <tr
                          key={user.id}
                          className="border-t border-gray-700 hover:bg-gray-700 transition-colors"
                        >
                          <td className="px-6 py-4 font-semibold">
                            {user.name}
                          </td>
                          <td className="px-6 py-4 text-sm">{user.email}</td>
                          <td className="px-6 py-4">{user.joinDate}</td>
                          <td className="px-6 py-4">
                            <span className="bg-primary/20 text-primary px-3 py-1 rounded-full text-sm">
                              {user.totalOrders}
                            </span>
                          </td>
                          <td className="px-6 py-4 font-semibold">
                            ₹{user.totalSpent}
                          </td>
                          <td className="px-6 py-4">
                            <button className="bg-blue-500 hover:bg-blue-600 p-2 rounded-lg transition-colors">
                              <Eye className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Orders Tab */}
            {activeTab === "orders" && (
              <div className="space-y-6">
                <h1 className="text-3xl font-bold text-white">
                  Orders Management
                </h1>

                <div className="bg-gray-800 rounded-lg shadow-lg overflow-x-auto">
                  <table className="w-full text-left text-gray-300">
                    <thead className="bg-gray-700 text-white">
                      <tr>
                        <th className="px-6 py-4 font-bold">Order ID</th>
                        <th className="px-6 py-4 font-bold">Customer</th>
                        <th className="px-6 py-4 font-bold">Date</th>
                        <th className="px-6 py-4 font-bold">Amount</th>
                        <th className="px-6 py-4 font-bold">Items</th>
                        <th className="px-6 py-4 font-bold">Status</th>
                        <th className="px-6 py-4 font-bold">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.map((order) => (
                        <tr
                          key={order.id}
                          className="border-t border-gray-700 hover:bg-gray-700 transition-colors"
                        >
                          <td className="px-6 py-4 font-semibold text-primary">
                            {order.id}
                          </td>
                          <td className="px-6 py-4">{order.customer}</td>
                          <td className="px-6 py-4 text-sm">{order.date}</td>
                          <td className="px-6 py-4 font-semibold">
                            ₹{order.amount}
                          </td>
                          <td className="px-6 py-4">
                            <span className="bg-gray-700 px-3 py-1 rounded-full text-sm">
                              {order.items} items
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span
                              className={`px-3 py-1 rounded-full text-sm font-semibold capitalize ${getStatusColor(order.status)}`}
                            >
                              {order.status}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <button
                              onClick={() => setSelectedOrder(order)}
                              className="bg-blue-500 hover:bg-blue-600 p-2 rounded-lg transition-colors"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Order Details Modal */}
                {selectedOrder && (
                  <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
                    <div className="bg-gray-800 rounded-lg p-8 max-w-md w-full">
                      <h2 className="text-2xl font-bold text-white mb-4">
                        Order Details
                      </h2>
                      <div className="space-y-3 text-gray-300">
                        <p>
                          <span className="font-semibold">Order ID:</span>{" "}
                          {selectedOrder.id}
                        </p>
                        <p>
                          <span className="font-semibold">Customer:</span>{" "}
                          {selectedOrder.customer}
                        </p>
                        <p>
                          <span className="font-semibold">Date:</span>{" "}
                          {selectedOrder.date}
                        </p>
                        <p>
                          <span className="font-semibold">Amount:</span> ₹
                          {selectedOrder.amount}
                        </p>
                        <p>
                          <span className="font-semibold">Items:</span>{" "}
                          {selectedOrder.items}
                        </p>
                        <p>
                          <span className="font-semibold">Status:</span>{" "}
                          <span
                            className={`px-2 py-1 rounded text-xs font-semibold capitalize ${getStatusColor(selectedOrder.status)}`}
                          >
                            {selectedOrder.status}
                          </span>
                        </p>
                      </div>
                      <button
                        onClick={() => setSelectedOrder(null)}
                        className="w-full bg-primary hover:bg-primary-dark text-white font-bold py-2 rounded-lg mt-6 transition-colors"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}

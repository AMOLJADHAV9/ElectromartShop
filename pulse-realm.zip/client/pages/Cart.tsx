import Layout from "@/components/Layout";
import { ArrowRight, ShoppingCart } from "lucide-react";
import { Link } from "react-router-dom";

export default function Cart() {
  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-16 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="bg-white rounded-xl shadow-lg p-12">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <ShoppingCart className="w-10 h-10 text-primary" />
            </div>
            <h1 className="text-4xl font-bold text-charcoal mb-4">
              Shopping Cart
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Your shopping cart page will display products you've added with quantity controls, pricing, and checkout options.
            </p>

            <div className="bg-orange-50 border-l-4 border-neon-orange p-6 rounded text-left mb-8 max-w-2xl mx-auto">
              <p className="text-gray-700 font-medium mb-2">Features to be implemented:</p>
              <ul className="text-gray-600 space-y-2 list-disc list-inside">
                <li>Display added products with images and prices</li>
                <li>Quantity adjustment controls</li>
                <li>Remove item functionality</li>
                <li>Order summary with subtotal, taxes, and shipping</li>
                <li>Proceed to Checkout button</li>
                <li>Continue Shopping link</li>
              </ul>
            </div>

            <Link
              to="/"
              className="inline-flex items-center gap-2 bg-primary text-white font-bold py-3 px-8 rounded-lg hover:bg-primary-dark transition-all duration-300 hover:shadow-lg active:scale-95"
            >
              Back to Home
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </div>
    </Layout>
  );
}

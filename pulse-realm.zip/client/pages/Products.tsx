import Layout from "@/components/Layout";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function Products() {
  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-16 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="bg-white rounded-xl shadow-lg p-12">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-4xl">📦</span>
            </div>
            <h1 className="text-4xl font-bold text-charcoal mb-4">
              Product Listing Page
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              This page will display a comprehensive product grid with filtering, sorting, and search capabilities.
            </p>

            <div className="bg-blue-50 border-l-4 border-primary p-6 rounded text-left mb-8 max-w-2xl mx-auto">
              <p className="text-gray-700 font-medium mb-2">Features to be implemented:</p>
              <ul className="text-gray-600 space-y-2 list-disc list-inside">
                <li>Product grid with image, name, price, and ratings</li>
                <li>Filter by category, price range, and ratings</li>
                <li>Sort by popularity, price, and newest</li>
                <li>Search functionality</li>
                <li>Pagination or infinite scroll</li>
                <li>Add to Cart and Wishlist buttons</li>
              </ul>
            </div>

            <Link
              to="/"
              className="inline-flex items-center gap-2 bg-primary text-white font-bold py-3 px-8 rounded-lg hover:bg-primary-dark transition-all duration-300 hover:shadow-lg active:scale-95"
            >
              Back to Home
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </div>
    </Layout>
  );
}
